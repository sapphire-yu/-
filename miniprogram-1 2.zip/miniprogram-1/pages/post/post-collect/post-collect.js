var dataObj = require("../../../data/data.js");
import{DBPost}from'../../../db/DBPost.js';
Page({
  data: {
  },

/*   获取数据//连接DBpost 动态获取data数据  */ 
  onLoad:function() {
  this.setData({
    postList:dataObj.postList
  })
        var dbPost=new DBPost();
        this.setData({
    postList:dbPost.getCollectedPosts()
    
        });
      },



    onTapToDetail(event){
        var postId= event.currentTarget.dataset.postId;
        console.log(postId);
        wx.navigateTo({
            url:'post-detail/post-detail?id='+postId,
        })
    }
})