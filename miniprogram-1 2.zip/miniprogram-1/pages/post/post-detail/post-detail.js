const { DBPost } = require("../../../db/DBPost");

// pages/post/post-detail/post-detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      isPlayingMusic:false
  },
  onMusicTap:function(event){
    if(this.data.isPlayingMusic){
      wx.pauseBackgroundAudio();
      this.setData({
        idPlayingMusic:false
      })
    }
    else{
      wx.playBackgroundAudio({
        dataUrl:'https://m701.music.126.net/20240517100303/b01ef0604dcdc011d533d688d75513e9/jdyyaac/obj/w5rDlsOJwrLDjj7CmsOj/16064354670/752f/c4b8/1f06/95adeb6dc54eb6949b3e082f985db6f9.m4a',
        title:'666',
        coverImgUrl:'https://cn.bing.com/images/search?q=%E5%9B%BE%E7%89%87&FORM=IQFRBA&id=08F055693DA526F576F8ABAE4686F7F493FAF1B5',

      })
      this.setData({
        isPlayingMusic:true
      })
    }
   },
onLoad:function(options){
    var postId = options.id;
    console.log(postId);
    this.dbPost=new DBPost(postId);
    this.postData=this.dbPost.getPostItemById().data;
    this.setData({post:this.postData})
    this.addReadingTimes();
    this.setMusicMonitior();
  
},
setMusicMonitior:function(){
    var that=this;
    wx.onBackgroundAudioStop(function(){
      that.setData({
        isPlayingMusic:flase
      })
    })
  },
  onRead:function() {
wx.setNavigationBarTitle({
  title: 'this.postData.title',
})
  },
onUpTap:function(event){
    var newData = this.dbPost.up();
    this.setData({
        'post.upStatus':newData.upStatus,
        'post.readingNum':newData.readingNum
    })
    wx.showToast({
        title: newData.upStatus ? "收藏成功" : "取消成功",
        duration: 1000,
        icon: "success",
        mask: true
      });
},
onCommentTap:function(event){
var id = event.currentTarget.dataset.postId;
wx.navigateTo({
    url:'../post-comment/post-comment?id='+id
})
},
  onCollectionTap: function(event) {
      
    var newData = this.dbPost.collect();
    this.setData({
      'post.collectionStatus': newData.collectionStatus,
      'post.collectionNum': newData.collectionNum
    });

    wx.showToast({
      title: newData.collectionStatus ? "收藏成功" : "取消成功",
      duration: 1000,
      icon: "success",
      mask: true
    });

   
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
  wx.stopBackgroundAudio()
  this.setData({
      isPlayingMusic:false
  })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})