Page({
  onTapJump:function(event){
    wx.navigateTo({
      url:"../post/post",
      success:function(){
        console.log("jump success")
      },
      fail:function(){
        console.log("jump failed")
      },
      complete:function(){
        console.log("jump complete")
      }
    });
  } ,
  onCollectJump:function(event){
    wx.navigateTo({
      url:"../post/post-collect/post-collect",
      success:function(){
        console.log("jump success")
      },
      fail:function(){
        console.log("jump failed")
      },
      complete:function(){
        console.log("jump complete")
      }
    });
  }
})