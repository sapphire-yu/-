/*var DBPost=function(){
  this.storageKeyName='postList';
}
DBPost.prototype={
  getAllPostData:function(){
    var res=wx.getStorageSync(this.storageKeyName);
    if(!res){
      res=require('../data/data').postList;
      this.execSetStorageSync(res);
    }
    return res;
  },
  execSetStorageSync:function(data){
    wx.setStorageSync(this.storageKeyName, data);
  },
};
module.exports={
  DBPost:DBPost
};*/
var util=require('../utils/util')
class DBPost{
  constructor(postId){
    this.storageKeyName='postList';
    this.postId=postId;
    this.collectedPosts = wx.getStorageSync('collectedPosts') || [];
  }
  newComment(newComment){
    this.updatePostData('comment',newComment);
}
  getPostItemById(){
      var postsData=this.getAllPostData();
      
      var len = postsData.length;
      for(var i=0;i<len;i++){
          if(postsData[i].postId==this.postId){
              return{
                  index:i,
                  data:postsData[i]
                  
              }
          }
      }
  }


  getAllPostData(){
    var res=wx.getStorageSync(this.storageKeyName);
    if(!res){
      res=require("../data/data.js").postList;
      this.execSetStorageSync(res);
    }
    return res;
  }

  getcollectpostdata(){

  }




  execSetStorageSync(data){
    wx.setStorageSync(this.storageKeyName, data);
  }
  collect(){
    return this.updatePostData('collect');
}
updatePostData(category,newComment){
    var itemData = this.getPostItemById(),
    postData = itemData.data,
    allPostData = this.getAllPostData();
     switch (category) {
        case 'collect':
          if (!postData.collectionStatus) {
            postData.collectionNum.array[0]++;
            postData.collectionStatus = true;
            // 如果之前不在收藏数组中，则添加
            if (!this.collectedPosts.includes(postData.postId)) {
              this.collectedPosts.push(postData.postId);
            }
          } else {
            postData.collectionNum.array[0]--;
            postData.collectionStatus = false;
            // 如果在收藏数组中，则移除
            this.collectedPosts = this.collectedPosts.filter(id => id !== postData.postId);
          }
          this.execSetStorageSync(this.collectedPosts, 'collectedPosts'); // 更新被收藏文章的数组
          break;
        case'up':
        if(!postData.upStatus){
            postData.readingNum++;
            postData.upStatus=true;
        }else{
            postData.readingNum--;
            postData.upStatus=false;
        }
        break;
        case"comment":
        postData.comments.push(newComment);
        postData.commentNum++;
            break;
            default:
                break;
    }
    allPostData[itemData.index]=postData;
this.execSetStorageSync(allPostData);
return postData;
}
up(){
    var data = this.updatePostData('up');
    return data;
}
getCollectedPosts() {
    var allPosts = this.getAllPostData();
    return allPosts.filter(post => this.collectedPosts.includes(post.postId));
  }
getCommentData(){
    var itemData = this.getPostItemById().data;
    itemData.comments.sort(this.commpareWithTime);
    var len = itemData.comments.length,
       comment;
    for(var i =0;i<len;i++){
        comment= itemData.comments[i];
        comment.create_time= util.getDiffTime(comment.create_time,true);
    }
    return itemData.comments;
}
compareWithTime(value1,value2){
var flag=parseFloat(value1.create_time)-parseFloat(value2.create_time);
if(flag<0){
    return 1;
}else if(flag>0){
    return -1;
}else{
    return 0;
}
}

};


export{DBPost}